/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.8.1/configure --target=mipsel-elf --prefix=/usr/local/mips --program-prefix=mips- --with-gnu-as --with-gnu-ld --enable-languages=c";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
